Settings.introText = "Welcome to Spawn Hero RPG!";
Settings.gameWinText = "You win!\n\nPlay again?";
Settings.gameOverText = "You died!\n\nPlay Again?";

Spawn.game = function(){





}
